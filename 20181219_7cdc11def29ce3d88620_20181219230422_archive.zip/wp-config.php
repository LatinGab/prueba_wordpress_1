<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'desafio_prueba_3');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', 'root');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'kITAk~?=&Mc+cwh2lHs[ER-^nfLs&$8<SuKVZ]K,;Hq>KcX$;4}Ckem`^%$SWy:<');
define('SECURE_AUTH_KEY',  '`r=ib[h%4Xt@{Ud@Jk~3??Yc1r$6~ynA]lH<PY_L{bwse*ji=<>GbEq9;guw[_C>');
define('LOGGED_IN_KEY',    'o7tE3YVzq2OrNk!G}b] oF 5G%U]A&_E|U(d&dh~qR#P,__jMV.@s~5y>G=:yY^c');
define('NONCE_KEY',        'PEiTZKka&7Uq#p(>f%h&<@:v]3ff<wK{2X7I%(Z-LVN+a|$TC?LK<so|fQ!ErZFx');
define('AUTH_SALT',        '#bUxZ5.yFclNtfrhUkJAN>0 eCtdRAmZne:$hl|aX-w%0bc|)eawOw8ub pS5nN}');
define('SECURE_AUTH_SALT', 'uI^Uib+6SC2S~;6r);*H(`kjI3?bt[73}1CN=#LIvS/ENVi:+*FmmjiI`PzbQ3R9');
define('LOGGED_IN_SALT',   '];Xw=Ej)3:/VA`qrX<uAk{y%H&PLTPCL{xSO/wEh6YKnU~!@Y]8l4wvl2Y$R@5F}');
define('NONCE_SALT',       '#}0?+N|jw`bK|nuW z!3Ipx3xVnAG?V@0o1NM>$rTiM~qV=T:q%3,#rM!<G4D} c');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
